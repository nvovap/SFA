//
//  NVPCategory.swift
//  Vega3
//
//  Created by Nevinniy Vladimir on 25.06.15.
//  Copyright (c) 2015 Nevinniy Vladimir. All rights reserved.
//

import Foundation
import CoreData
import UIKit

@objc(NVPCategory)
class NVPCategory: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var residues: NSSet
    @NSManaged var outlets: NSSet
    
    
    class func  getCategory(name: String) -> (NVPCategory) {
        
        let managedObjectContext = ((UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext)!
        //var desc: NSEntityDescription = NSEntityDescription.entityForName("Category", inManagedObjectContext: managedObjectContext)!
        
        var request = NSFetchRequest(entityName: "Category")
        
        var predicate = NSPredicate(format: "name == \""+name+"\"")
        
        request.predicate = predicate
        
        
        if let results: [NVPCategory] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPCategory] {
        
    
        
        //if let results: NSArray = managedObjectContext.executeFetchRequest(request, error: nil)  {
            
            print(results.last)
            
            // let cc: Category = results.lastObject
            
            if let category = results.last  {
                return category
            }
            
        }
        
        //if let results = _results {
        
        
        var desc: NSEntityDescription = NSEntityDescription.entityForName("Category", inManagedObjectContext: managedObjectContext)!
        var category: NVPCategory = NVPCategory(entity: desc, insertIntoManagedObjectContext: managedObjectContext)
        
        category.name    = name
        
        
        return category
    }


}
