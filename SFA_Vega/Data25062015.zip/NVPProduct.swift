//
//  NVPProduct.swift
//  Vega3
//
//  Created by Nevinniy Vladimir on 25.06.15.
//  Copyright (c) 2015 Nevinniy Vladimir. All rights reserved.
//

import Foundation
import CoreData
import UIKit

@objc(NVPProduct)
class NVPProduct: NSManagedObject {

    @NSManaged var artikle: String
    @NSManaged var barcode: String
    @NSManaged var code: String
    @NSManaged var fullname: String
    @NSManaged var id: String
    @NSManaged var idGroup: String
    @NSManaged var name: String
    @NSManaged var order: NSNumber
    
    
    class func insertProduct(id _id: String, name: String, fullname: String, code: String, idGroup: String, barcode: String, artikle: String, order: Int) -> (NVPProduct?)  {
        
        if let product = self.getProduct(id: _id) {
            return product
        }

        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            
            if var desc: NSEntityDescription = NSEntityDescription.entityForName("Product", inManagedObjectContext: managedObjectContext) {
                var product: NVPProduct = NVPProduct(entity: desc, insertIntoManagedObjectContext: managedObjectContext)
                
                product.id      = _id
                product.name    = name
                product.fullname = fullname
                product.code    = code
                product.idGroup = idGroup
                product.barcode = barcode
                product.artikle = artikle
                product.order   = order
                
                return product
            }
        }
        
        return nil
        
        
    }
    
    class func  getProduct(id _id: String) -> (NVPProduct?) {
        
        let managedObjectContext = ((UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext)!
        //var desc: NSEntityDescription = NSEntityDescription.entityForName("Category", inManagedObjectContext: managedObjectContext)!
        
        var request = NSFetchRequest(entityName: "Product")
        
        var predicate = NSPredicate(format: "id == \""+_id+"\"")
        
        request.predicate = predicate
        
        
        if let results: [NVPProduct] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPProduct] {
            
            print(results.last)
            
            
            if let product = results.last  {
                return product
            }
            
        }
        
        return nil
    }
    
    
    class func getProducts(name: String!) -> ([NVPProduct]?)  {
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            var request = NSFetchRequest(entityName: "Product")
            
            if let name = name {
                var predicate = NSPredicate(format: "name like '"+name+"*'")
                request.predicate = predicate
            }
            
            
            let sortOrder = NSSortDescriptor(key: "order", ascending: true)
            
            request.sortDescriptors = [sortOrder]
            
            
            
            
            if let results: [NVPProduct] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPProduct] {
                return results
                
            }
           
        }
        
        return nil
        
        
    }


}
