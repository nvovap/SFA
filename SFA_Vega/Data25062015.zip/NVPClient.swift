//
//  NVPClient.swift
//  Vega3
//
//  Created by Nevinniy Vladimir on 25.06.15.
//  Copyright (c) 2015 Nevinniy Vladimir. All rights reserved.
//

import Foundation
import CoreData
import UIKit

@objc(NVPClient)
class NVPClient: NSManagedObject {

    @NSManaged var code: String
    @NSManaged var fullname: String
    @NSManaged var id: String
    @NSManaged var name: String
    @NSManaged var okpo: String
    @NSManaged var outlets: NSSet
    
    
    class func insertStore(id _id: String, name: String, fullname: String, code: String, okpo: String) -> (NVPClient?)  {
        
        if let client = self.getClient(id: _id) {
            return client
        }
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            
            if var desc: NSEntityDescription = NSEntityDescription.entityForName("Client", inManagedObjectContext: managedObjectContext) {
                var client: NVPClient = NVPClient(entity: desc, insertIntoManagedObjectContext: managedObjectContext)
                
                client.id        = _id
                client.name      = name
                client.code      = code
                client.fullname  = fullname
                client.okpo      = okpo
                
                return client
            }
        }
        
        return nil
        
        
    }
    
    
    class func  getClient(id _id: String) -> (NVPClient?) {
        
        let managedObjectContext = ((UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext)!
        //var desc: NSEntityDescription = NSEntityDescription.entityForName("Category", inManagedObjectContext: managedObjectContext)!
        
        var request = NSFetchRequest(entityName: "Client")
        
        var predicate = NSPredicate(format: "id == \""+_id+"\"")
        
        request.predicate = predicate
        
        
        if let results: [NVPClient] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPClient] {
            
            print(results.last)
          
            
            if let client = results.last  {
                return client
            }
            
        }
        
         return nil
    }
    
    class func getClients(name: String!) -> ([NVPClient]?)  {
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            var request = NSFetchRequest(entityName: "Client")
            
            if let name = name {
                var predicate = NSPredicate(format: "name like '"+name+"*'")
                request.predicate = predicate
            }
            
            
            let sortOrder = NSSortDescriptor(key: "name", ascending: true)
            
            request.sortDescriptors = [sortOrder]
            
            
            
            
            if let results: [NVPClient] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPClient] {
                return results
                
            }
            
        }
        
        return nil
        
        
    }


}
