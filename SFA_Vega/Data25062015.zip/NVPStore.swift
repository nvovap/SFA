//
//  NVPStore.swift
//  Vega3
//
//  Created by Nevinniy Vladimir on 25.06.15.
//  Copyright (c) 2015 Nevinniy Vladimir. All rights reserved.
//

import Foundation
import CoreData
import UIKit


@objc(NVPStore)
class NVPStore: NSManagedObject {

    @NSManaged var adress: String
    @NSManaged var code: String
    @NSManaged var id: String
    @NSManaged var idClient: String
    @NSManaged var name: String
    @NSManaged var category: NVPCategory
    @NSManaged var client: NVPClient
    
    
    class func insertStore(id _id: String, name: String, code: String,  idClient: String, category categoryName: String, adress: String) -> (NVPStore!)  {
        
        if let store = self.getStore(id: _id) {
            return store
        }
        
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            
            if var desc: NSEntityDescription = NSEntityDescription.entityForName("Store", inManagedObjectContext: managedObjectContext) {
                var store: NVPStore = NVPStore(entity: desc, insertIntoManagedObjectContext: managedObjectContext)
                
                store.id        = _id
                store.name      = name
                store.code      = code
                store.idClient  = idClient
                store.adress    = adress
                
                
                if let client = NVPClient.getClient(id: idClient){
                    store.client = client
                }
                
                let category  = NVPCategory.getCategory(categoryName)
                store.category  = category
                
                               
                
                
                return store
            }
        }
        
        return nil
        
        
    }
    
    
    class func  getStore(id _id: String) -> (NVPStore?) {
        
        let managedObjectContext = ((UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext)!
        //var desc: NSEntityDescription = NSEntityDescription.entityForName("Category", inManagedObjectContext: managedObjectContext)!
        
        var request = NSFetchRequest(entityName: "Store")
        
        var predicate = NSPredicate(format: "id == \""+_id+"\"")
        
        request.predicate = predicate
        
        
        if let results: [NVPStore] = managedObjectContext.executeFetchRequest(request, error: nil) as? [NVPStore] {
            
            print(results.last)
            
            
            if let store = results.last  {
                return store
            }
            
        }
        
        return nil
    }
    
}

