//
//  NVPResiduesCategory.swift
//  Vega3
//
//  Created by Nevinniy Vladimir on 25.06.15.
//  Copyright (c) 2015 Nevinniy Vladimir. All rights reserved.
//

import Foundation
import CoreData
import UIKit

@objc(NVPResiduesCategory)
class NVPResiduesCategory: NSManagedObject {

    @NSManaged var idProduct: String
    @NSManaged var quantity: NSNumber
    @NSManaged var category: NVPCategory
    
    
    class func insertResiduesCategory(idProduct _id: String, quantity: NSNumber, category categoryName: String) -> (NVPResiduesCategory?)  {
        
        if let managedObjectContext = (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext{
            
            if var desc: NSEntityDescription = NSEntityDescription.entityForName("ResiduesCategory", inManagedObjectContext: managedObjectContext) {
                var residuesCategory: NVPResiduesCategory = NVPResiduesCategory(entity: desc, insertIntoManagedObjectContext: managedObjectContext)
                
                residuesCategory.idProduct     = _id
                residuesCategory.quantity      = quantity
                residuesCategory.category      = NVPCategory.getCategory(categoryName)

                return residuesCategory
            }
        }
        
        return nil
    }
    
  
}
